package com.example.webbrowser;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    EditText urlEditText;
    Button loadButton, backButton, forwardButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        urlEditText = findViewById(R.id.urlEditText);
        loadButton = findViewById(R.id.loadButton);
        backButton = findViewById(R.id.backButton);
        forwardButton = findViewById(R.id.forwardButton);

        // تنظیمات WebView
        webView.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // دکمه تأیید
        loadButton.setOnClickListener(v -> {
            String input = urlEditText.getText().toString().trim();
            String url;

            if (input.startsWith("http://") || input.startsWith("https://")) {
                url = input;
            } else if (input.contains(".")) {
                url = "http://" + input;
            } else {
                // اگر فقط متن بود، جستجو در گوگل
                url = "https://www.google.com/search?q=" + input.replace(" ", "+");
            }

            webView.loadUrl(url);
        });

        // دکمه برگشت
        backButton.setOnClickListener(v -> {
            if (webView.canGoBack()) {
                webView.goBack();
            } else {
                Toast.makeText(this, "صفحه‌ای برای برگشت وجود ندارد", Toast.LENGTH_SHORT).show();
            }
        });

        // دکمه جلو
        forwardButton.setOnClickListener(v -> {
            if (webView.canGoForward()) {
                webView.goForward();
            } else {
                Toast.makeText(this, "صفحه‌ای برای جلو رفتن وجود ندارد", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // جلوگیری از خروج با دکمه Back سیستم
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
