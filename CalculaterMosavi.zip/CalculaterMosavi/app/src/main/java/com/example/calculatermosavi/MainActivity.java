package com.example.calculatermosavi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText num1EditText, num2EditText;
    Button btnAdd, btnSubtract, btnMultiply, btnDivide, btnCalculate;
    String operation = "+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1EditText = findViewById(R.id.num1EditText);
        num2EditText = findViewById(R.id.num2EditText);
        btnAdd = findViewById(R.id.btnAdd);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnCalculate = findViewById(R.id.btnCalculate);

        // انتخاب عملگر
        btnAdd.setOnClickListener(v -> operation = "+");
        btnSubtract.setOnClickListener(v -> operation = "-");
        btnMultiply.setOnClickListener(v -> operation = "*");
        btnDivide.setOnClickListener(v -> operation = "/");

        btnCalculate.setOnClickListener(v -> {
            try {
                double num1 = Double.parseDouble(num1EditText.getText().toString());
                double num2 = Double.parseDouble(num2EditText.getText().toString());
                double result = 0;

                switch (operation) {
                    case "+": result = num1 + num2; break;
                    case "-": result = num1 - num2; break;
                    case "*": result = num1 * num2; break;
                    case "/":
                        if (num2 != 0)
                            result = num1 / num2;
                        else {
                            Toast.makeText(this, "تقسیم بر صفر مجاز نیست!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        break;
                }

                Toast.makeText(this, "نتیجه: " + result, Toast.LENGTH_LONG).show();

            } catch (NumberFormatException e) {
                Toast.makeText(this, "لطفاً هر دو عدد را وارد کنید", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
