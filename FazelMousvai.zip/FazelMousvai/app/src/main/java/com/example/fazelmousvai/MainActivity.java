package com.example.fazelmousvai;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextName;
    Button buttonLogin;
    TextView textViewWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewWelcome = findViewById(R.id.textViewWelcome);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                if (!name.isEmpty()) {
                    textViewWelcome.setText("خوش آمدید " + name + "!");
                } else {
                    textViewWelcome.setText("لطفا نام خود را وارد کنید.");
                }
            }
        });
    }
}